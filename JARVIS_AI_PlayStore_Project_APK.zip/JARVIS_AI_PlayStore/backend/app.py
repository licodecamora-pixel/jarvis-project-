import os
from fastapi import FastAPI
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI()

class ChatRequest(BaseModel):
    message: str

@app.post("/api/chat")
def chat(req: ChatRequest):
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return {"reply": "The AI service is not configured yet. Please contact the app administrator."}
    try:
        client = OpenAI(api_key=key)
        result = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            instructions=(
                "You are JARVIS, a concise, calm, helpful English-language personal AI assistant. "
                "Do not claim to control the user's phone, access private data, or perform actions "
                "unless a tool actually provides that capability. Ask for confirmation before "
                "any consequential action."
            ),
            input=req.message
        )
        return {"reply": result.output_text}
    except Exception:
        return {"reply": "Sorry, the AI service is temporarily unavailable. Please try again."}
