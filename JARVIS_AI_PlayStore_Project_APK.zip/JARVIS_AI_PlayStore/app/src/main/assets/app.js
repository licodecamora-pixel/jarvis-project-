const $=id=>document.getElementById(id), box=$("messages");
function add(kind,text){const el=document.createElement("article");el.className=kind;const b=document.createElement("b");b.textContent=kind==="user"?"YOU":"JARVIS";const p=document.createElement("p");p.textContent=text;el.append(b,p);box.append(el);box.scrollTop=box.scrollHeight}
function busy(on){document.querySelector(".reactor-wrap").classList.toggle("busy",on);$("state").textContent=on?"PROCESSING":"STANDBY";$("core-status").textContent=on?"BUSY":"READY"}
function ask(text){text=text.trim();if(!text)return;add("user",text);$("prompt").value="";busy(true);if(window.Android&&Android.ask)Android.ask(text);else{busy(false);add("jarvis","Native Android bridge unavailable.")}}
$("form").addEventListener("submit",e=>{e.preventDefault();ask($("prompt").value)});
$("mic").addEventListener("click",()=>{if(window.Android&&Android.listen){busy(true);Android.listen()}else add("jarvis","Voice input is available in the installed Android app.")});
$("clear").addEventListener("click",()=>{box.replaceChildren();add("jarvis","Console cleared. At your service.")});
window.onJarvisReply=text=>{busy(false);add("jarvis",text);if(window.Android&&Android.speak)Android.speak(text)};
window.onJarvisTranscript=text=>{busy(false);if(text){$("prompt").value=text;ask(text)}};
window.onJarvisError=text=>{busy(false);add("jarvis",text)};
window.setListening=active=>{busy(active);$("state").textContent=active?"LISTENING":"STANDBY"};
