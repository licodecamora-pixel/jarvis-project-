package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val io = Executors.newSingleThreadExecutor()

    // Replace this with your HTTPS backend URL before release.
    // Never put an OpenAI API key in this Android project.
    private val backendUrl = "https://YOUR-BACKEND-DOMAIN.example/api/chat"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface fun speak(text: String) {
            runOnUiThread {
                tts?.speak(text.take(2500), TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
            }
        }

        @JavascriptInterface fun listen() {
            runOnUiThread { startListening() }
        }

        @JavascriptInterface fun ask(message: String) {
            io.execute {
                val result = requestAssistant(message)
                runOnUiThread {
                    val safe = JSONObject.quote(result)
                    web.evaluateJavascript("window.onJarvisReply && window.onJarvisReply($safe)", null)
                }
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendTranscriptError("Speech recognition is not available on this device.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setListeningState(true) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { setListeningState(false) }
            override fun onError(error: Int) {
                setListeningState(false)
                sendTranscriptError("I couldn't hear that. Please try again.")
            }
            override fun onResults(results: Bundle?) {
                setListeningState(false)
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                val safe = JSONObject.quote(text)
                web.evaluateJavascript("window.onJarvisTranscript && window.onJarvisTranscript($safe)", null)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        recognizer?.startListening(intent)
    }

    private fun requestAssistant(message: String): String {
        if (backendUrl.contains("YOUR-BACKEND-DOMAIN")) {
            return "The AI service is not connected yet. Configure your secure HTTPS backend URL in MainActivity.kt."
        }
        return try {
            val conn = (URL(backendUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            conn.outputStream.use {
                it.write(JSONObject().put("message", message).toString().toByteArray(Charsets.UTF_8))
            }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            conn.disconnect()
            JSONObject(body).optString("reply", "I received an empty response.")
        } catch (_: Exception) {
            "I can't reach the AI service right now. Please check your internet connection."
        }
    }

    private fun setListeningState(active: Boolean) {
        web.evaluateJavascript("window.setListening && window.setListening($active)", null)
    }

    private fun sendTranscriptError(message: String) {
        web.evaluateJavascript("window.onJarvisError && window.onJarvisError(${JSONObject.quote(message)})", null)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        io.shutdown()
        web.destroy()
        super.onDestroy()
    }
}
