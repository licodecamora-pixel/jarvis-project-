# Build an installable JARVIS AI APK using only an Android phone

This project can produce a **debug APK** that you can download and install directly on your Android phone for testing. You do not need Android Studio or a laptop; GitHub Actions builds it in the cloud.

## A. Upload the project to GitHub
1. Sign in to GitHub in your phone browser.
2. Create a new private repository named `jarvis-ai-android`.
3. Open the repository and choose **Add file > Upload files**.
4. Extract the project ZIP using your phone's file manager. Upload the contents of the extracted `JARVIS_AI_PlayStore` folder, including the hidden `.github` folder. If your browser hides hidden folders, create `.github/workflows/android-build.yml` in GitHub's web editor and paste in the workflow file from the ZIP.
5. Commit the files.

## B. Build the APK in the cloud
1. Open the repository's **Actions** tab.
2. Select **Build JARVIS AI Android APK and AAB**.
3. Tap **Run workflow** and confirm.
4. Wait for the workflow to finish successfully.
5. Open the completed run and find **Artifacts**.
6. Download **jarvis-ai-debug-apk**. Extract the downloaded artifact ZIP if your phone does not do so automatically.
7. Tap the `.apk` file and follow Android's prompt to allow installation from that source, if you choose to. Only install APKs you built from your own trusted repository.

## Important difference
- `jarvis-ai-debug-apk`: directly installable on Android for personal testing. It is a debug build, not the final Play Store release.
- `jarvis-ai-release-aab`: separate Android App Bundle artifact for later Play Store preparation. It needs proper release signing before production upload.

## Before the app can answer with an online AI
The starter app still contains a placeholder backend URL in `MainActivity.kt`. Deploy the sample backend to a secure HTTPS host and replace the placeholder with your real endpoint. Keep any AI API key on the server; never place it in the Android app or a public repository.

## Safety and publishing
- Do not share GitHub passwords, verification codes, signing keys, or API keys in chat.
- A debug APK may show Android's warning because it is not distributed through Play Protect/Play Store. Install only your own build from your trusted repository.
- For Play Store publishing, use a properly signed release AAB, complete testing and privacy disclosures, and follow current Play Console requirements. If you are under 18, a parent or guardian must manage the developer account and publishing process.
- A successful build does not guarantee Play Store approval.
