# Privacy Policy — JARVIS AI

**Effective date:** [insert date]  
**Developer:** [developer or organization name]  
**Contact:** [support email]

JARVIS AI is a personal assistant app. This template must be completed and published at a public HTTPS URL before Play Store submission. Replace every bracketed item and make sure it accurately reflects the final app and backend.

## Information processed
- **Microphone and speech:** When a user taps the microphone button, the app invokes Android speech recognition using English (United States). Audio handling is subject to the selected Android speech-recognition provider's terms and privacy practices.
- **Chat messages:** Text submitted by the user is sent to the developer-operated HTTPS backend to generate an AI response. The backend may process the message using the configured AI provider.
- **Diagnostics:** [Describe any crash logs, analytics, or diagnostics. If none, state none.]

## Purpose and sharing
Information is used to provide assistant responses, operate the service, troubleshoot failures, and protect the service. [Name the AI provider, hosting provider, and other processors actually used.] Do not claim that data is never shared unless that is true for the deployed service.

## Retention and deletion
[Explain whether prompts, logs, and diagnostics are retained, for how long, and how users can request deletion.]

## Security
The app communicates with the configured backend over HTTPS. No system can guarantee absolute security.

## Children
[Describe the intended audience and applicable age-related practices.]

## Changes and contact
We may update this policy. Contact [support email] with privacy questions or deletion requests.
