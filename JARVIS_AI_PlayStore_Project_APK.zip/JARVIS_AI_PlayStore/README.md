# JARVIS AI — Android Studio project

A starter native Android app with a holographic blue-violet dashboard, English speech recognition, English text-to-speech, and a secure-backend chat connection.

## Important: what is included
- Native Android Kotlin shell and WebView-based dashboard assets.
- Android SpeechRecognizer configured for `en-US`.
- Android TextToSpeech configured for `Locale.US`.
- Chat client that sends messages to your own HTTPS backend.
- FastAPI backend sample in `backend/`.

This is a source project, not a prebuilt or signed APK/AAB. You must build and test it in Android Studio.

## 1. Requirements
- Android Studio current stable version.
- JDK 17 (Android Studio can use its bundled JBR).
- Android SDK Platform 36 and Build Tools installed from SDK Manager.
- A physical Android phone for microphone/speech testing.
- An HTTPS host for the AI backend before public release.

## 2. Open the project
1. Extract `JARVIS_AI_PlayStore_Project.zip`.
2. In Android Studio choose **Open** and select the extracted `JARVIS_AI_PlayStore` folder.
3. Allow Gradle sync to finish.
4. If prompted, install Android SDK Platform 36.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press **Run** to install a debug build.

Application ID currently is `com.example.jarvisai`. Before release, choose a permanent unique ID and do not change it after publishing.

## 3. Connect the AI backend
The Android app intentionally does not contain an OpenAI API key. APK/AAB files can be inspected, so embedding a secret key in the app is unsafe.

1. Deploy the FastAPI app in `backend/` to a server with HTTPS.
2. On the server install `backend/requirements.txt`.
3. Set the secret environment variable `OPENAI_API_KEY` on the server (never commit it to source control).
4. Start the service with `uvicorn app:app --host 0.0.0.0 --port 8000` (configure a production ASGI server/reverse proxy and HTTPS for public use).
5. In `MainActivity.kt`, replace `https://YOUR-BACKEND-DOMAIN.example/api/chat` with your real HTTPS endpoint.
6. Rebuild and test. Do not use plain HTTP in a release app.

## 4. Build an Android App Bundle (.aab)
1. In Android Studio open **Build > Generate Signed Bundle / APK**.
2. Select **Android App Bundle** and press **Next**.
3. Create a new keystore if this is your first release. Store it safely and keep backups. Never share it or commit it to Git.
4. Enter the key alias and passwords. Select the `release` build variant.
5. Finish the wizard. Android Studio generates the signed `.aab` under `app/release/` (the exact output location may be shown in the wizard).
6. Keep the same signing identity for future updates. For Play App Signing, follow the Play Console prompts to enroll and upload the upload key certificate.

Alternative Gradle task: `./gradlew bundleRelease` (Windows: `gradlew.bat bundleRelease`). You still need a signing configuration/keystore for a signed release bundle.

## 5. Google Play Console checklist
- Create a Google Play Console developer account. Account holder must meet Google's age and identity requirements; a parent/guardian should handle the account if the developer is under 18.
- Pay the one-time registration fee shown by Google.
- Create the app listing and upload the signed AAB.
- Complete the Data safety form, content rating, target audience, app access, ads declaration, and privacy policy.
- Provide a public privacy policy URL that accurately describes microphone use, speech processing, messages sent to your backend, retention, analytics, and deletion/contact process.
- Add app icon, screenshots, short/full descriptions, and any required feature graphic.
- Run internal testing first. New personal developer accounts may have additional closed-testing requirements before production access.
- Submit for review. Approval and publication are decided by Google.

## 6. Privacy and safety notes
- Microphone access is only used after the user taps the microphone button. Android prompts for permission.
- Speech recognition may use the device's speech service and can transmit audio to the service provider according to that provider's terms. Disclose this in your privacy policy.
- Chat text is sent to the HTTPS backend you configure. Explain processing and retention in your privacy policy.
- The app does not currently access contacts, SMS, call logs, precise location, or control other apps.
- Do not add hidden recording or background listening. Keep microphone use visible and user-initiated.
- This starter uses a WebView with JavaScript bridge. Keep dashboard assets trusted and bundled locally; do not load arbitrary websites into this WebView.

## 7. Before public release
- Replace the example application ID with one you own.
- Add a production privacy policy and support contact.
- Add launcher icon and store graphics.
- Test on several Android versions and screen sizes.
- Test microphone denial, offline mode, backend errors, accessibility, and app lifecycle.
- Review current Play Console policies and target API deadlines at submission time.

## Build without a computer
See `BUILD_FROM_ANDROID_PHONE.md` for a phone-only cloud build route using GitHub Actions.


## Installable APK for Android testing
The GitHub Actions workflow also builds a directly installable `jarvis-ai-debug-apk` artifact. Download it from the completed workflow run's Artifacts section. This debug APK is for testing, not a final Play Store release.
